---
name: panos-dlp-decrypt-migration
description: Use for PAN-OS DLP, file blocking, App-ID, and decryption architecture, and for the three-platform proxy-to-PA migration/parity program covering Skyhigh SWG (Aetna and CVS estates, which are materially different configs) and Zscaler ZIA, including Entra Tenant Restrictions v1 (live on proxies today) and v2 (PAN-OS target state, forward-proxy header injection). Trigger on any mention of "Skyhigh," "SK_to_PA," "Zscaler," "ZIA," DLP patterns/dictionaries, decrypt/decryption coverage, TRv2, PAN-OS Data Filtering profiles, segments MID/WIN/PAZSHDC/RRISHDC, Aetna Cluster B / CVS Cluster A, or HICN/GEMS ID/Member ID detection, even if not phrased as a migration question. Also consult cvs-netsec-context for the shared decrypt-gap and App-ID-adoption facts this skill builds on.
---

# PAN-OS DLP, Decrypt Architecture & Proxy-to-PA Migration (Skyhigh + Zscaler)

## Core dependency chain — lead with this

**Aetna's HTTPS decrypt coverage gap is the root upstream blocker for DLP, IPS, and Content-ID inspection simultaneously.** Any conversation about why DLP or IPS isn't catching something on Aetna segments should trace back to this first, rather than treating each inspection failure as an independent gap. Don't propose DLP or Content-ID fixes without first checking whether decrypt coverage is the actual blocker.

## Program overview — three platforms, not one

File, data, and threat security functions historically provided by proxy platforms are moving to the Palo Alto NGFW estate as the primary enforcement point. There are **three distinct legacy platforms** in scope, and they are not interchangeable configs despite two of them sharing a vendor:

| Platform | Scope | Key architectural trait |
| --- | --- | --- |
| **Aetna Skyhigh SWG (SH) Proxy** | Aetna estate | Two-pass decrypt (identity bypass → category/domain allow-list); fail-closed on bad certs (blocks) |
| **CVS Skyhigh SWG (SH) Proxy** | CVS estate | Explicit opt-in decrypt (boolean flag, default false); **fail-open on bad certs — this is the single highest-priority finding below** |
| **Zscaler ZIA** | Cloud proxy, both estates | Bypass-by-default at the rule level (Default action = Do Not Inspect); 39 numbered rules, Admin Rank 7 |

**Do not assume "Skyhigh" means one config.** Aetna and CVS run the identical Skyhigh SWG build (`12.2.23` build `57025`, hotfix 0 — confirmed identical, so every difference below is a policy-authoring choice, not version skew) but have diverged significantly since a shared ancestor config: CVS has 41 DLP dictionaries vs. Aetna's 16, CVS uses Kerberos-first tiered auth vs. Aetna's NTLM-only, and — critically — **CVS's certificate-trust blocking logic exists but is disabled, while Aetna's identical logic is enabled and blocking.** Confirmed directly evidence: a rule literally named `Allow Aetna DMZs` exists byte-identical in both configs — `enabled=true` on Aetna, `enabled=false` on CVS.

### The single most important cross-platform finding

**CVS Health's Skyhigh proxy does not block on bad TLS certificates.** It runs the exact same detection logic as the Aetna proxy — self-signed, expired, revoked, or untrusted-CA certificates are all detected — but where Aetna blocks the connection, CVS only logs it and lets the traffic through. The rule set to block this traffic already exists in CVS's configuration; it is simply switched off. This is directly relevant to PCI DSS v4.0.1 and NIST SP 800-53 compliance work. Recommended action: enable or formally risk-accept CVS's disabled certificate-blocking rule group to match Aetna's enforced posture.

## Skyhigh-to-PA migration (SK_to_PA_Security_Model_and_Parity_Plan, now on v9)

**Scope discipline established in v9:** Sections 1-7 cover **Aetna Cluster B** (`MID-PAN-PROD-01` / `WIN-PAN-PROD-01`) in full detail; **CVS Cluster A** (`PAZSHDC-SEC-PAN-PROD-01` / `RRISHDC-SEC-PAN-PROD-01`) is included from the Security Profile Coverage Matrix onward, only where independently verified, and is never presented as a combined posture with Aetna Cluster B — the two clusters are structurally independent estates. Primary sources: `Aetna-SH-Proxy-2026-07-21.backup` (SK proxy), `Panoramas_-_7-31-2026.zip` (Panorama configs, both clusters), `Palos_-_7-31-2026.zip` (49 individual firewall configs). Preserve this document's own convention of tracking corrections explicitly (it flags where its own earlier claims were wrong once deeper verification contradicted them) — this is an audit-grade methodology, not a narrative-polish step, and should be preserved when extending the plan.

**Not a rule-by-rule mapping.** The two platforms are architecturally different enough that rule-by-rule comparison produces false equivalencies in both directions — SK is a two-tier architecture (stateless L3/4 firewall + proxy doing all app-layer security, reachable only via WCCP/PAC redirection, bypassable if redirection isn't configured) vs. PA's single-tier inline model (App-ID/Content-ID native, two independent rulebases — Decryption and Security — confirmed to share **zero** match criteria with each other, so nothing keeps their scopes aligned automatically).

### Headline findings (both clusters)

- **The dominant traffic path on both clusters carries an alert-only profile with no URL Filtering, File Blocking, or Data Filtering attached at all** — ~90% of rules on Aetna Cluster B, ~99.7% on CVS Cluster A. Real enforcement exists only in narrow exception paths.
- **Vulnerability Protection is alert-only across every one of 31 profile groups individually verified on both clusters** — including profiles using the `_Best_Practice_SP` naming convention. This is a platform-wide pattern, not an isolated gap; don't assume a "Best Practice"-named profile is enforcing without checking.
- SK's Data Filtering (DLP) blocks SSN/PCI/HICN in production today. The PA equivalent is **built but not yet live** on Aetna Cluster B. CVS Cluster A has a real Data Filtering profile (`NAB - Initial Data Filtering`, 28 PAN-OS predefined patterns) in its narrow enforcing path, but its action is **alert, not block**.
- O365/SaaS traffic is permitted with `application=any` and no App-ID discrimination on Aetna Cluster B — confirmed directly against live rules. **Audit this pattern across every egress-facing firewall in the estate**, not just this cluster.
- Interzone/intrazone default posture differs by cluster: Aetna has hardened intrazone-default to drop across nearly every device group; CVS Cluster A largely remains on PAN-OS factory default (allow).
- Real data gaps are stated explicitly, not filled by inference: several device-group-to-physical-firewall mappings are unconfirmed (notably the AWS device group and most of CVS Cluster A's egress firewalls), and the config export is missing the entire Windsor-side GLR/Officeext/EDMZ firewalls plus half the Windsor DMZ pair.

### Corrected finding (methodology example — preserve this pattern)

An earlier claim that CVS Cluster A's URL category blocking is "confirmed nowhere blocked" was **wrong and has been corrected**: real category-based blocking exists on the `SPG-Proxy-Web-Mail` profile (2 rules; online-storage-and-backup and social-networking genuinely block). What remains a real gap: enforcement is confined to those 2 rules; the dominant paths on both clusters (`Alert-All-SPG` on CVS, `hcb_DMZ`/`hcb_GLR` on Aetna) still have no URL filtering at all; and named individual services (Outlook, OneDrive, ShareFile, BoxAccess) sit alert-only even within the enforcing profile.

### Data Filtering restructuring decision (this engagement)

Data Filtering patterns are currently **bundled** — multiple patterns sharing one action in a single rule (confirmed on both the live CVS Cluster A profile, `NAB - Initial Data Filtering`: 22 patterns/one action, and the staged Aetna configuration, `AET-DataFilter-STAGED`). Bundling forces every pattern to share one action — SSN can't be treated differently from a lower-confidence pattern like a state driver's license format without splitting them apart. **Decided this engagement: restructure to one pattern per rule.** Confirmed technically supported — each pattern already has its own independently-delimited match/occurrence/confidence block. Note: splitting alone does not enable AD-group or domain-based inspection exceptions — that needs a separate security-policy rule matching the specific group/domain, attached to the profile carrying the corresponding pattern variant. Both pieces are needed together.

### File-blocking mechanism gap

SK identifies files partly by filename extension; PA identifies files only by content signature. **Six legacy Windows script/shortcut extensions SK recognizes have no corresponding content-signature type on PA today** — close where mechanically possible via profile reassignment; document the residual six-extension gap as a platform limitation requiring endpoint-based control if closure is required.

## Three-platform equivalency analysis (Skyhigh vs. PA vs. Zscaler — Proxy_vs_PA_vs_Zscaler_Equivalency, now on v6)

This report extends the standalone `PA vs. Zscaler — DLP & Malware/Threat Prevention Equivalency Analysis` (v8.1) to add Skyhigh SWG as a third platform, parsed from a Coordinator config backup dated 2026-06-03. **Critical caveat carried through: the Skyhigh backup only exports the appliance's *custom* rule-group library** — built-in/default rule sets, where URL-category blocking and DLP-engine wiring normally live, are absent. Every proxy finding distinguishes "configured as an object" (exists in backup) from "confirmed enforced" (wired to an active, enabled rule up the full rule-group hierarchy — a rule can read `enabled="true"` while sitting inside a disabled parent group).

### No single platform leads across the board

- **Zscaler** is most mature on DLP and malware/threat blocking — the only platform confirmed *actively enforcing* (not just alerting) in both domains, consistent with 3+ years of tuning.
- **Palo Alto** is strongest on file blocking and the only one with confirmed comprehensive URL category enforcement (Cluster A) — but its DLP and most of its threat-prevention stack are alert-only.
- **The proxy (Skyhigh)** has the richest DLP *content definitions* (genuinely CVS/Aetna-specific: HICN, GEMS ID, Member ID — no PA or Zscaler equivalent for GEMS/Member ID) and a mature TLS-integrity layer none of the other reports examine — but its DLP wiring is split by direction (see below), its AV stack lacks a working second layer, and its URL-category policy isn't visible in this export at all.

### DLP — enforcement splits by direction on the proxy

| Platform | Confirmed enforcement |
| --- | --- |
| Skyhigh — outbound/upload | **Active.** `CVS Health SSN HICN Block`, `CVS Health PCI Block`, `CVS Health Member ID` genuinely block, gated by per-user allow-lists. |
| Skyhigh — inbound/download | **Disabled.** The classification-triggered block rule sits inside a group with `enabled="false"`; the entire `Data Loss Prevention w/ICAP` integration is disabled at the same level. |
| PA Panorama | **Alert-only, confirmed.** `NAB - Initial Data Filtering`'s single rule is `action=alert` across all 22 patterns, applied via 17 SPGs / 42 of 43 rules. |
| Zscaler | **Actively blocking (partially).** 5 of 22 rules confirmed Block (`PRD_DLP_CloudApps`, `PRD_DLP_UA_Restricted_Data`, `PRD_DLP_Secrets-Block`, `PRD_DLP_Slack_Block`, `PRD_DLP_UA_Rstrc_Webex`); 10 monitor-only, 7 disabled/draft. |

The proxy's outbound HICN/SSN/PCI/Member-ID blocking is genuinely comparable to Zscaler's most mature active-block rules — PA is the outlier: alert-only, and **no HICN/MBI pattern exists on PA at all**, even though HICN is one of the proxy's best-covered categories and a CMS-regulated identifier.

### Ready-to-implement PA change: add HICN detection

Two new PA Custom Data Patterns, translated directly from the proxy's existing HICN dictionaries:

| Pattern | Type | Regex | Source |
| --- | --- | --- | --- |
| HICN – Numeric Format | Regular Expression | `\b\d{3}-?\d{2}-?\d{4}-?[A-Za-z]{1,2}\b` | Consolidated from proxy's `CVS Health HICN` / `HICN RegEx` dictionaries |
| HICN – Keyword/Context | Regular Expression | `(?i)\b(HICN\|HIC\s*#\|HICN\s*#\|HIC\s*No\.?\|HICN\s*No\.?\|Medicare\s+HIC(?:N)?\|Health\s+Insurance\s+Claim\s+Number)\b` | Deduplicated from proxy's 14-term `HICN Terms` / `CVS Health HICN Keywords` |

Implementation path: add as objects under Objects → Custom Objects → Data Patterns in the device group owning `NAB - Initial Data Filtering` (shared across Meritain, PPOM, LV-Colo, Proxy SPGs), then attach the same way as the existing 22 predefined patterns. **Decision needed, not assumed:** the profile's current rule is alert-only for all 22 patterns (PA default, not a deliberate CVS choice). Adding HICN to that same rule inherits alert-only. A block outcome for HICN specifically requires its own rule with `action=block`, since editing the shared rule changes behavior for all 22 patterns at once.

### TLS/certificate-integrity port to PA's Decryption Profile — 5 of 8 checks port cleanly

| Proxy check | PA equivalent | Mapping |
| --- | --- | --- |
| Block Expired Server/CA Certificates | Decryption Profile → SSL Forward Proxy → Block sessions with expired certificates | Direct match |
| Block Self-Signed Certificates | → Block sessions with untrusted issuers | Direct match |
| Block Unknown/Untrusted CAs | → Block sessions with untrusted issuers | Direct match (PA doesn't distinguish unknown vs. untrusted CA) |
| Block Revoked Certificates | Certificate Profile → OCSP/CRL checking + Block session if certificate status is unknown | Direct match, but lives on the Certificate Profile, not the Decryption Profile — check both objects together |
| Block Weak Key Exchange | SSL Protocol Settings → min TLS version + allowed key-exchange algorithms | Partial — no single "key exchange bits" toggle; achievable by disabling weak suites |
| Block Unsafe Signature Algorithms | *No direct equivalent found* | **Gap** — no signature-algorithm blocklist on PAN-OS Decryption Profiles; Certificate Profile min-key-size as partial substitute |
| Block Common Name Mismatch | *No direct equivalent found* | **Gap** — proxy-specific (requested hostname vs. presented cert CN/SAN); PA's re-signing model doesn't expose an equivalent |
| Block Certificate Chain Violations (path length) | *No direct equivalent found* | **Gap** — not a standard Decryption Profile toggle; verify against specific PAN-OS version |

The 3 remaining gaps (signature algorithm, CN mismatch, path length) are worth a direct conversation with Palo Alto TAM/engineering, not logged as confirmed-impossible.

### Other portable items

- **CONNECT port restriction (SSH/Telnet tunneling):** proxy blocks HTTPS CONNECT tunnels to ports 22/23. PA's App-ID-native equivalent is *stronger* than a port copy — deny the `ssh`/`telnet` App-IDs outright (catches tunneling regardless of port), plus an explicit `tcp/22`/`tcp/23` service deny as defense-in-depth. Place in pre-rulebase, ahead of general egress-allow rules.
- **Not portable / no action needed:** Geolocation blocking (proxy's blocklist is currently empty — nothing to migrate); proxy-chaining prevention (defends against a proxy-architecture-specific failure mode with no PA equivalent).

### Comparison summary by domain

| Domain | Proxy (Skyhigh) | PA | Zscaler |
| --- | --- | --- | --- |
| Antivirus/Malware | Gateway Anti-Malware active (block threshold 90), but sandbox (MATD) and secondary AV (VX) both disabled; ICAP hooks to Symantec exist but server lists are empty | Mixed: `AV_Best_Practice_SP` genuinely blocks (rare); `Alert-All-AV` (99%+ of estate) is alert-only | Block by default, all categories, bidirectional — matches Zscaler's own published best practice |
| File Blocking | Confirmed active — executables, restricted extensions, password-protected/nested archives, confirmed-virus content | Explicit unconditional Block for encrypted archives/documents and high-risk executables (18 SPGs) | Scan-then-block sandbox model; encrypted/unscannable files **allow by default** |
| URL/Content Filtering | Confirmed active — 47-category global blocklist + separate cloud-storage rule (category IDs not resolvable in this export) | Genuine comprehensive blocking (~30-34 categories) on Cluster A across 7 profiles; Cluster B far weaker (1 of 7 groups, 12 categories) | No standalone policy — category logic embedded in Cloud App Control business-exception rules; structurally different, not directly comparable |
| C2/Botnet detection | Not found in visible policy | Alert-only across both Alert-All and Best Practice profiles | Block — Botnet/Fraud/Unauthorized Communication Protection |
| TLS/Cert integrity | Confirmed monitor-only in practice — the rule group with genuine block actions is disabled; the live group only logs | Not covered (Panorama security-rule/SPG scope, not a proxy TLS layer) | Not covered in reviewed export |
| SaaS Tenant Restriction (Azure AD) | **Confirmed active** — MS Tenant Restrictions v1 header injection | Supported via URL Filtering → HTTP Header Insertion ("Office 365" predefined type) but not confirmed configured | Has a dedicated, more purpose-built Tenant Restriction policy but not confirmed configured for this tenant |

## Zscaler ZIA SSL/TLS Inspection Policy

Extracted from the Zscaler Cloud Portal "Print All Policies" export (tenant CVS Health Corporation, admin `najohnson@cvshealth.com`, exported 2026-05-27). This is a distinct rulebase from URL Filtering, Firewall Filtering, and Malware Policy — governs which sessions get decrypted vs. pass through encrypted. Evaluated top-down, first match wins; 39 numbered rules + Default, all Admin Rank 7.

- **Overall posture is bypass-by-default** — the Default rule (bottom of rulebase) is Do Not Inspect. Only traffic explicitly matched by an active Inspect rule gets decrypted.
- **12 rules Inspect, 20 Do Not Inspect (+ Default), 8 Disabled.** Primary bulk-inspection coverage is a single rule (36, "G-SSL_Inspection_Phase1", ~90 URL categories).
- **Dead-code flag (P2):** Rule 38 ("InspectALL", Any → Inspect) sits *above* Rule 39 (Atlassian) and Default in evaluation order. Since first-match-wins, Rule 38 as written should already catch everything that fell through Rules 1-37 — making Rule 39 and Default potentially unreachable. Verify in-console whether Rule 38 carries hidden exclusion criteria not visible in the print export.
- **Standing blind spot:** Rules 1, 2, 6, 7, 9 bypass SSL inspection for GCP/AWS/Azure Cloud Connector traffic specifically because Zscaler can't validate the RootCA these connectors present — stated in-rule as an interim workaround pending a Zscaler-provided RootCA store modification process.
- **"Phase 2" bulk inspection exists but is Disabled** (Rule 37 — broader superset of Rule 36's categories). Current live scope is Phase 1 (Rule 36) only; confirm whether Phase 2 rollout is planned or intentionally deferred.
- Rule 15 ("Riverbend") permits TLS 1.0 minimum for named users — below the 1.2 floor used everywhere else; worth confirming this exception is still required.
- Combined with broad developer-tooling and SaaS one-click exemptions (Rules 24, 29, 31-33), a meaningful share of enterprise HTTPS egress is not decrypted or inspected at the proxy layer at all.

## Cross-platform header rewriting

All three platforms implement header insertion as a per-rule action tied to a matching condition, not a general rewrite capability (Zscaler: "Header Insertion Profile" referenced from a URL Filtering rule; Skyhigh: `com.scur.engine.headerfilter` engine).

- **Aetna and CVS both source their Azure AD Tenant Restrictions v1 domain list from the same `proxyconsole.aetna.com` URL and use an identical tenant-context GUID** (`fabb61b8-3afe-4e75-b934-a47f782b8cd7`) — confirms centralized management across both proxy estates. Zscaler enforces the same Microsoft mechanism independently via its own rule (`CVSH-MS365_Tenant`).
- **Zscaler Rule 32 ("Claude_HeaderInsertion")** injects a header insertion profile ("Claude Insertion") scoped to a custom `Claude_URLs` category for two named users, intended to enforce Claude/Anthropic tenant restrictions (`anthropic-allowed-org-ids: <org-UUID>`). The actual header profile contents were **not** in the policy export (Header Insertion Profiles are separate config objects) — the exact value has not been confirmed against Anthropic's documented format. This requires SSL Inspection to actively decrypt `Claude_URLs` traffic to function at all — cross-check against the ZIA SSL inspection rules above.
- **CVS-only:** Slack Workspace Approval headers (`X-Slack-Allowed-Workspaces-Requester`, `X-Slack-Allowed-Workspaces`) — no Aetna equivalent.
- CVS's DLP block-header (`x-mwg-block-message`) and CSP-rewrite rules exist identically to Aetna's but are **dormant** — the parent "Agentless notifications" group is disabled on CVS while enabled on Aetna.
- The YouTube Edu header (`X-YouTube-Edu-Filter`) on both Skyhigh proxies carries a placeholder value, not a real School ID — non-functional if YouTube for Schools restriction is an actual requirement.

## Aetna vs. CVS Skyhigh — structural divergence (same software build, different policy authorship)

Both run identical `12.2.23` build `57025` — every difference below is a policy choice, not version skew.

- **Authentication:** Aetna is NTLM-only with unconditional static bypass exemptions. CVS runs Kerberos-first, three-mode tiered auth (simple NTLM / WCCP-transparent Kerberos-then-NTLM-fallback / explicit-proxy Kerberos-then-NTLM-fallback), with bypass gated specifically to an explicit-proxy-port list rather than unconditional. If unifying, CVS's model is the defensible reference.
- **DLP dictionaries:** Aetna 16 vs. CVS 41 — CVS has dedicated HIPAA and SOX classification aggregations, banking-PII coverage (bank account, IBAN, routing, CID regex), AWS keys, and password dictionaries with no Aetna equivalent.
- **ICAP directionality:** Aetna is request-direction only (no RespMod list object exists anywhere in its config — response/download-direction ICAP scanning is architecturally absent). CVS has both directions plus a Symantec third-party engine — though CVS's generic ReqMod/RespMod server objects resolve to unbound placeholder addresses (`0.0.0.0:1344`) while their calling rules are enabled; this may be overridden per-node or may be non-functional in production — verify against the live appliance.
- **Anti-malware tuning:** Aetna runs 9 overlapping objects across two naming families with an internal inconsistency ("High Setting" = 85 in one family, 80 in the other). CVS runs 2 flat objects, uniform posture.
- **Standing shared risk:** both estates fetch customer-maintained dynamic lists (allow/deny/no-auth, tenant-restriction domains, HTTPS-scanning opt-in lattices) from the same `proxyconsole.aetna.com` console — CVS's dynamic-list infrastructure has never migrated off Aetna-owned infrastructure, even for CVS-specific object names created after the naming convention diverged.
- Both estates' customer-maintained list objects (234 total across both) are `CUSTOMER_MAINTAINED` stubs with **empty `<content/>` in the coordinator backup** — their actual contents are only recoverable from the live console or an appliance `list export`, never from a backup file alone.

## DLP pattern library

- US driver's license regex patterns have been built for **all 50 states + DC**, sourced from the lipe-dev/NTSI GitHub gist and corrected for PAN-OS compatibility. If asked to extend or debug DLP regex patterns, check compatibility against PAN-OS's regex engine quirks the same way — don't assume a generic PCRE pattern will work unmodified. Several state formats are pure-numeric with very high false-positive risk (flagged per-state) and should be paired with contextual keyword matching if deployed.
- Native PA Data Filtering profile objects are **built but not wired to security policy rules** estate-wide (see cvs-netsec-context). Before reporting DLP as "implemented" anywhere, verify the profile is actually attached to a rule, not just defined as an object.
- HICN has no PA-native predefined pattern — see the ready-to-implement HICN patterns above before treating HICN detection as a platform limitation.

## Decryption architecture

Deep technical work spans named segments: **MID, WIN, PAZSHDC, RRISHDC** (mapping to Aetna Cluster B / CVS Cluster A above). When discussing decrypt architecture, ask which segment is in scope if not specified — findings and coverage differ by segment, and generalizing across all four is likely to overstate or understate coverage.

## TRv2 (Entra Tenant Restrictions v2) — distinguish from what's live today

**What's live today (v1):** Aetna, CVS, and Zscaler all currently run **Tenant Restrictions v1** — proxy/firewall-side HTTP header injection (`Restrict-Access-To-Tenants` / `Restrict-Access-Context` on the Skyhigh proxies; a dedicated Tenant Restriction policy on Zscaler) that strips client-supplied values and writes the organization's own, on every request to Microsoft sign-in domains.

**Target state on PA (v2):** PAN-OS forward proxy **HTTP header injection**, deployed across the CVS/Aetna Panorama estate. This is a forward-proxy/header-injection design specifically — don't suggest alternate TRv2 implementation paths (e.g., client-side or IdP-side enforcement) without flagging that it's a different architecture than what's been built. Note: Microsoft's current recommendation is actually **Tenant Restrictions v2**, which moves enforcement into Entra cross-tenant access policies rather than depending on proxy/firewall header injection — worth considering as the actual target state rather than replicating v1's header-injection mechanism a third time on PA. Delivering v1-style header insertion on PA requires (1) SSL Forward Proxy decryption on the Microsoft login domains — a common field misconfiguration, since header insertion doesn't work without decrypting the session first; (2) a URL Filtering Profile with the predefined "Office 365" HTTP Header Insertion entry populated with the tenant ID/domain; (3) a Security Policy allowing that traffic with the profile attached.

## Related audit context

SOC 2 audit response work touches the partially decommissioned PDC environment (PDC-013, PDC-020, PDC-029 AuditBoard requests) and the Aetna PCI environment (IPS tuning, Splunk eStreamer blockers, network discovery from seed ranges to reverse-engineer PCI scope). If DLP/decrypt work intersects with PCI scope questions, flag the connection to this audit work rather than treating it as unrelated. The CVS Skyhigh cert-blocking gap above is directly relevant to PCI DSS v4.0.1 and NIST SP 800-53 compliance work and should be cross-referenced there.
